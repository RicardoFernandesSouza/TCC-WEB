
-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cpf_cnpj` varchar(14) NOT NULL,
  `mobile` int(13) NOT NULL,
  `email` varchar(250) NOT NULL,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`id`, `name`, `cpf_cnpj`, `mobile`, `email`, `username`, `password`) VALUES
(13, 'Ivan', '56776534556', 90908888, 'ivan@professor', 'ivan', 'ivan'),
(14, 'Ricardo Fernandes de Souza', '39672792876', 995420037, 'ricardo_fernandes.souza@hotmail.com', 'adm', 'adm'),
(16, 'LetÃ­cia Carolina', '33322211112', 949664886, 'leticia.carolina@yahoo.com', 'carol', '123'),
(19, 'Teste', '11122233312', 12123434, 'teste.com', 'tcc', 'qqq');
