
-- --------------------------------------------------------

--
-- Estrutura da tabela `resp`
--

CREATE TABLE `resp` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cpf_cnpj` varchar(14) NOT NULL,
  `email` varchar(250) NOT NULL,
  `mobile` int(13) NOT NULL,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `resp`
--

INSERT INTO `resp` (`id`, `name`, `cpf_cnpj`, `email`, `mobile`, `username`, `password`) VALUES
(1, 'Ricardo Fernandes de Souza e ADRIANO', '111.111.111-67', 'ricardo_fernandes.souza@hotmail.com', 2147483647, 'RespRicardo', '123456'),
(3, 'Adriano Fiore Borella', '67887667890', 'adriano.borella@hotmail.com', 9877890, 'afafa', 'adada');
