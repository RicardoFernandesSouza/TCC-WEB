
-- --------------------------------------------------------

--
-- Estrutura da tabela `useradmr`
--

CREATE TABLE `useradmr` (
  `id` int(11) NOT NULL,
  `first` varchar(128) NOT NULL,
  `last` varchar(128) NOT NULL,
  `uid` varchar(20) NOT NULL,
  `pwd` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `useradmr`
--

INSERT INTO `useradmr` (`id`, `first`, `last`, `uid`, `pwd`) VALUES
(1, 'Ricardo', 'Fernandes de Souza', 'admin', '123456');
