
-- --------------------------------------------------------

--
-- Estrutura da tabela `residencia`
--

CREATE TABLE `residencia` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `hood` varchar(100) NOT NULL,
  `zip_code` int(8) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `ie` int(11) NOT NULL,
  `begindate` date NOT NULL,
  `enddate` date NOT NULL,
  `idcliente` int(11) NOT NULL,
  `idresp` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `residencia`
--

INSERT INTO `residencia` (`id`, `address`, `hood`, `zip_code`, `city`, `state`, `ie`, `begindate`, `enddate`, `idcliente`, `idresp`, `created`, `modified`) VALUES
(28, 'Rua Teste', 'Teste', 13320040, 'Salto', 'Sao Paulo', 0, '2017-06-05', '2017-06-15', 13, 1, '2017-06-05 19:17:50', '2017-08-02 18:22:41');
