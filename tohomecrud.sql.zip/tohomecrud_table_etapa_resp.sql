
-- --------------------------------------------------------

--
-- Estrutura da tabela `etapa_resp`
--

CREATE TABLE `etapa_resp` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `id_residencia` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
