
-- --------------------------------------------------------

--
-- Estrutura da tabela `etapa_cliente`
--

CREATE TABLE `etapa_cliente` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(14) NOT NULL,
  `id_residencia` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
