
--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `etapa_cliente`
--
ALTER TABLE `etapa_cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_etapa_cliente_residencia` (`id_residencia`);

--
-- Indexes for table `etapa_resp`
--
ALTER TABLE `etapa_resp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_etapa_resp_residencia` (`id_residencia`);

--
-- Indexes for table `residencia`
--
ALTER TABLE `residencia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente` (`idcliente`),
  ADD KEY `resp` (`idresp`);

--
-- Indexes for table `resp`
--
ALTER TABLE `resp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_name`
--
ALTER TABLE `tbl_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_name1`
--
ALTER TABLE `tbl_name1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `useradmr`
--
ALTER TABLE `useradmr`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `etapa_cliente`
--
ALTER TABLE `etapa_cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `etapa_resp`
--
ALTER TABLE `etapa_resp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `residencia`
--
ALTER TABLE `residencia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `resp`
--
ALTER TABLE `resp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_name`
--
ALTER TABLE `tbl_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `tbl_name1`
--
ALTER TABLE `tbl_name1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `etapa_cliente`
--
ALTER TABLE `etapa_cliente`
  ADD CONSTRAINT `fk_etapa_cliente_residencia` FOREIGN KEY (`id_residencia`) REFERENCES `residencia` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `etapa_resp`
--
ALTER TABLE `etapa_resp`
  ADD CONSTRAINT `fk_etapa_resp_residencia` FOREIGN KEY (`id_residencia`) REFERENCES `residencia` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `residencia`
--
ALTER TABLE `residencia`
  ADD CONSTRAINT `cliente` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `resp` FOREIGN KEY (`idresp`) REFERENCES `resp` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
