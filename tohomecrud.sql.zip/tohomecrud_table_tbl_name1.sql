
-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_name1`
--

CREATE TABLE `tbl_name1` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `id_residencia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_name1`
--

INSERT INTO `tbl_name1` (`id`, `name`, `details`, `id_residencia`) VALUES
(1, 'Etapa x', 'xxcffddeed', 30),
(2, 'Etapa x', 'Teste', 31),
(3, 'etapa x', 'aaaaa', 32),
(4, 'etapa y', 'bbbbb', 32);
