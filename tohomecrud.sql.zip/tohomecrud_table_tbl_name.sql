
-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_name`
--

CREATE TABLE `tbl_name` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `id_residencia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_name`
--

INSERT INTO `tbl_name` (`id`, `name`, `details`, `id_residencia`) VALUES
(44, 'aaa', 'aaaa', 28),
(45, 'sss', 'sss', 28),
(46, 'dddd', 'dddd', 28),
(47, 'Etapa 1', 'aeaweaw', 30),
(48, 'Etapa 1', 'teste', 31),
(49, 'Etapa 2', 'teste tcc', 31),
(50, 'Etapa 1', 'descriÃ§Ã£o', 32),
(51, 'Etapa 4', 'Mudar essa bagaÃ§a', 28);
